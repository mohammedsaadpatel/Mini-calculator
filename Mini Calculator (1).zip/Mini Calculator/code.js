onEvent("add_btn", "click", function( ) {
  setNumber("label_ans", getNumber("text_input1") + getNumber("text_input2"));
});
onEvent("sub_btn", "click", function( ) {
  setNumber("label_ans", getNumber("text_input1") - getNumber("text_input2"));
});
onEvent("mult_btn", "click", function( ) {
  setNumber("label_ans", getNumber("text_input1") * getNumber("text_input2"));
});
onEvent("div_btn", "click", function( ) {
  setNumber("label_ans", getNumber("text_input1") / getNumber("text_input2"));
});
